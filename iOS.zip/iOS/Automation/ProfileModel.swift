//
//  ProfileModel.swift
//  Automation
//
//  Created by Emiliano Alvarez on 6/26/17.
//  Copyright © 2017 Globant. All rights reserved.
//

import Foundation

class ProfileModel {

  var name: String
  var lastName: String
  var gender: String
  var eyeColor: String

  init(name: String, lastName: String, gender: String, eyeColor: String) {
    self.name = name
    self.lastName = lastName
    self.gender = gender
    self.eyeColor = eyeColor
  }
}
