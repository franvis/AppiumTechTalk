//
//  ProfileShared.swift
//  Automation
//
//  Created by Emiliano Alvarez on 6/26/17.
//  Copyright © 2017 Globant. All rights reserved.
//

import Foundation

class ProfileShared {

  static public let sharedInstance = ProfileShared()

  private init() {}

  var profileModel: ProfileModel?
}
