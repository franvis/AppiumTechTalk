//
//  ViewController.swift
//  Automation
//
//  Created by Emiliano Alvarez on 6/26/17.
//  Copyright © 2017 Globant. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
  }

  @IBAction func resetProfilePressed(_ sender: Any) {
    ProfileShared.sharedInstance.profileModel = nil
  }
}
