//
//  ProfileViewController.swift
//  Automation
//
//  Created by Emiliano Alvarez on 6/26/17.
//  Copyright © 2017 Globant. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {

  @IBOutlet weak var nameLabel: UILabel!
  @IBOutlet weak var genderLabel: UILabel!
  @IBOutlet weak var eyeColorLabel: UILabel!

  override func viewDidLoad() {
    super.viewDidLoad()
    nameLabel.text = nil
    genderLabel.text = nil
    eyeColorLabel.text = nil
  }

  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    guard let profile = ProfileShared.sharedInstance.profileModel else {
      nameLabel.text = "Missing Profile."
      return
    }

    nameLabel.text = "\(profile.name) \(profile.lastName)"
    genderLabel.text = "Gender: \(profile.gender)"
    eyeColorLabel.text = "Eye Color: \(profile.eyeColor)"
  }
}
