//
//  ListTableViewCell.swift
//  Automation
//
//  Created by Emiliano Alvarez on 6/26/17.
//  Copyright © 2017 Globant. All rights reserved.
//

import UIKit

class ListTableViewCell: UITableViewCell {

  @IBOutlet weak var titleLabel: UILabel!
  @IBOutlet weak var descriptionLabel: UILabel!

  override func awakeFromNib() {
    super.awakeFromNib()
    self.accessibilityIdentifier = "tableViewCell"
  }

  func setup(title: String?, description: String?) {
    titleLabel.text = title
    descriptionLabel.text = description
  }
}
