//
//  FormViewController.swift
//  Automation
//
//  Created by Emiliano Alvarez on 6/26/17.
//  Copyright © 2017 Globant. All rights reserved.
//

import UIKit

class FormViewController: UIViewController {

  fileprivate let eyeColors = ["", "Blue", "Green", "Brown", "Black", "Other"]

  @IBOutlet weak var errorLabel: UILabel!
  @IBOutlet weak var nameTextField: UITextField!
  @IBOutlet weak var lastnameTextField: UITextField!
  @IBOutlet weak var genderLabel: UILabel!
  @IBOutlet weak var genderSegmentedControl: UISegmentedControl!
  @IBOutlet weak var eyeColorLabel: UILabel!
  @IBOutlet weak var eyeColorPicker: UIPickerView!
  @IBOutlet weak var submitButton: UIButton!
  @IBOutlet weak var successLabel: UILabel!

  @IBAction func submitButtonPressed(_ sender: Any) {
    errorLabel.text = nil

    guard let nameText = nameTextField.text,
          !nameText.isEmpty else {
      errorLabel.text = "Missing Name."
      return
    }

    guard let lastNameText = lastnameTextField.text,
          !lastNameText.isEmpty else {
      errorLabel.text = "Missing Lastname."
      return
    }

    let genderSelectedIndex = genderSegmentedControl.selectedSegmentIndex

    guard genderSelectedIndex != -1,
          let genderTitle = genderSegmentedControl.titleForSegment(at: genderSelectedIndex) else {
      errorLabel.text = "Missing Gender."
      return
    }

    let eyeColorTitle = eyeColors[eyeColorPicker.selectedRow(inComponent: 0)]

    guard !eyeColorTitle.isEmpty else {
      errorLabel.text = "Missing EyeColor."
      return
    }

    successLabel.isHidden = false

    let profileModel = ProfileModel(
      name: nameText,
      lastName: lastNameText,
      gender: genderTitle,
      eyeColor: eyeColorTitle
    )

    ProfileShared.sharedInstance.profileModel = profileModel
  }

  override func viewDidLoad() {
    eyeColorPicker.dataSource = self
    eyeColorPicker.delegate = self
    lastnameTextField.delegate = self
    nameTextField.delegate = self
    genderSegmentedControl.accessibilityIdentifier = "genderButton"
  }

  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    errorLabel.text = nil
    nameTextField.text = nil
    lastnameTextField.text = nil
    successLabel.isHidden = true
  }
}


extension FormViewController: UITextFieldDelegate {

  func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    textField.resignFirstResponder()
    return true
  }
}

extension FormViewController: UIPickerViewDataSource, UIPickerViewDelegate {

  func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
    return 5
  }

  func numberOfComponents(in pickerView: UIPickerView) -> Int {
    return 1
  }

  func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
    return eyeColors[row]
  }
}
