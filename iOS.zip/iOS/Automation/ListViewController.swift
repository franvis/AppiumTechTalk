//
//  ListViewController.swift
//  Automation
//
//  Created by Emiliano Alvarez on 6/26/17.
//  Copyright © 2017 Globant. All rights reserved.
//

import UIKit

class ListViewController: UIViewController {

  @IBOutlet weak var tableView: UITableView!

  var data: [[String: Any]] = [
    ["id": 1,
     "title": "Title 1",
     "description": "Description 1."],
    ["id": 2,
     "title": "Title 2",
     "description": "Description 2."],
    ["id": 3,
     "title": "Title 3",
     "description": "Description 3."],
    ["id": 4,
     "title": "Title 4",
     "description": "Description 4."],
    ["id": 5,
     "title": "Title 5",
     "description": "Description 5."],
    ["id": 6,
     "title": "Title 6",
     "description": "Description 6."],
    ["id": 7,
     "title": "Title 7",
     "description": "Description 7."],
    ["id": 8,
     "title": "Title 8",
     "description": "Description 8."],
    ["id": 9,
     "title": "Title 9",
     "description": "Description 9."],
    ["id": 10,
     "title": "Title 10",
     "description": "Description 10."],
    ["id": 12,
     "title": "Title 12",
     "description": "Description 12."],
    ["id": 11,
     "title": "Title 11",
     "description": "Description 11."]
  ]

  func sortList() {
    data = data.sorted(by: { (list1, list2) -> Bool in
      return (list1["id"] as! Int) < (list2["id"] as! Int)
    })
  }

  override func viewDidLoad() {
    super.viewDidLoad()
    tableView.dataSource = self
    //sortList()
  }
}

extension ListViewController: UITableViewDataSource {

  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return data.count
  }

  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "listCell") as! ListTableViewCell
    let indexData = data[indexPath.row]
    let title = indexData["title"] as? String
    let description = indexData["description"] as? String
    cell.setup(title: title, description: description)
    return cell
  }
}
